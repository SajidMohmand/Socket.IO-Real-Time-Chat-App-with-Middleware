/* eslint-disable no-undef */
import React from "react";
import { useEffect, useState } from "react";
import { io } from "socket.io-client";
import { Container, TextField, Button } from "@mui/material";
import { useMemo } from "react";

const App = () => {

  const socket = useMemo(() => io("http://localhost:3000"), []);
  const [message, setMessage] = useState("");

  const [messages, setMessages] = useState([]);
  const [socketId, setSocketId] = useState("");
  const [room, setRoom] = useState("");
  const [roomName, setRoomName] = useState("");
  const [createRoom, setCreateRoom] = useState("");
  const [roomMessage, setRoomMessage] = useState("");
  const [roomMessages, setRoomMessages] = useState([]);


  const handleSubmit = (e) => {
    e.preventDefault();
    socket.emit("message", { message, room });
  }
  const joinRoomHandler = (e) => {
    e.preventDefault();
    socket.emit("join-room", createRoom);
  }

  const handleRoomSubmit = (e) => {
    e.preventDefault();
    socket.emit("roomMessage", { roomMessage, roomName });
  }


  useEffect(() => {
    socket.on("connect", () => {
      console.log("connected Id: ", socket.id);
      setSocketId(socket.id);
    });


    // socket.on("welcome", (s)=>{
    //   console.log(s);
    // })
    socket.on("recieve", (s) => {
      console.log(s);
    })

    socket.on("message-receieve", (data) => {
      console.log(data)
      setMessages(messages => [...messages, data])
    })

    socket.on("roomMessage-receieve", (data)=> {
      console.log(data)
      setRoomMessages(roomMessages => [...roomMessages, data])
    })
  }, [socket]);



  return (
    <Container maxWidth="sm">
      <h1>Socket IO</h1>
      <h2>{socketId}</h2>

      <form onSubmit={handleSubmit}>
        <TextField
          value={message}
          onChange={e => setMessage(e.target.value)}
          fullWidth
          label="Message"
          variant="outlined"
          margin="normal"
        />

        <TextField
          value={room}
          onChange={e => setRoom(e.target.value)}
          fullWidth
          label="Put Room ID"
          variant="outlined"
          margin="normal"
        />

        <Button type="submit" variant="contained" color="primary" fullWidth>
          Send
        </Button>

        <div>
          {messages.map((msg, index) => (
            <p key={index}>{msg}</p>
          ))}
        </div>
      </form>


      <h1>Rooms</h1>
      <form onSubmit={joinRoomHandler}>
        <TextField
          value={createRoom}
          onChange={e => setCreateRoom(e.target.value)}
          fullWidth
          label="Create Room Name"
          variant="outlined"
          margin="normal"
        />
        <Button type="submit" variant="contained" color="primary" fullWidth>
          Join Room
        </Button>
      </form>


      <form onSubmit={handleRoomSubmit}>

        <TextField
          value={roomName}
          onChange={e => setRoomName(e.target.value)}
          fullWidth
          label="RoomName"
          variant="outlined"
          margin="normal"
        />
        <TextField
          value={roomMessage}
          onChange={e => setRoomMessage(e.target.value)}
          fullWidth
          label="Message"
          variant="outlined"
          margin="normal"
        />

        <Button type="submit" variant="contained" color="primary" fullWidth>
          Send
        </Button>

        <div>
        {roomMessages.map((msg, index) => (
          <p key={index}>{msg}</p>
        ))}
      </div>
      </form>


      


    </Container>
  );
};

export default App;
