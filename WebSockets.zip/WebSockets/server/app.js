import express from "express";
import {Server} from "socket.io";
import {createServer} from "http";


const port = 3000;

const app = express();
const server = createServer(app);

const io = new Server(server, {
    cors: {
        origin: "http://localhost:5173",
        method: ["GET", "POST"],
        credentials: true,
    }
}
);

app.get("/", (req,res)=>{
    res.send("Hello world!");
})

io.on("connection", (socket) => {

    console.log("User Connected:",socket.id)

    socket.on("message", (data)=>{
        console.log(data)
        // io.emit("message-receieve", data);
        // socket.broadcast.emit("recieve", data.message)
        socket.to(data.room).emit("message-receieve", data.message)

    })

    socket.on("roomMessage", (data) => {

        console.log(`room message: ${data.roomMessage}`)
        console.log(`room Name: ${data.roomName}`)
        socket.to(data.roomName).emit("roomMessage-receieve", data.roomMessage)

    })

    socket.on("join-room", (room)=> {

        console.log(`join room ${room}`)
        socket.join(room);



    })
    
    
    // socket.emit("welcome", `welcome to team : ${socket.id}`)
    // socket.broadcast.emit("welcome",`socket_id: ${socket.id} Just Join Server`)

    socket.on("disconnect", ()=>{
        console.log(`${socket.id} user disconnect.`)
    })
})


server.listen(port, ()=>{
    console.log(`server is running on port: ${port}`);
})